var Option = Backbone.Model.extend({
	defaults: {
		id: "",
		name: "",
		link: "",
		image_url: "http://demo.sc.chinaz.com/Files/pic/icons/4438/0.png",
	},
    initialize: function(){
    }
});