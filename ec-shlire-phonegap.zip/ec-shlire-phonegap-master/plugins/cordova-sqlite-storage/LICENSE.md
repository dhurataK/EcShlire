# Licenses

## Common Javascript

MIT or Apache 2.0

## Android version

MIT or Apache 2.0

## iOS version

MIT only

## Windows (8.1) version

MIT or Apache 2.0

### SQLite3-WinRT

by @doo (doo GmbH)

MIT License

